const a={appName:"Minimal UI"};export{a as C};
